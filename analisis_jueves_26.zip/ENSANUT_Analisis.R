library(survey) #install.packages("survey")
library(readr)
library(tidyverse)
ensanut <- read_csv("Downloads/ENSANUT_1 (1).csv")

#Obtengo un identificador por persona pegando el número de casa + el de persona
#sólo pasa en ENSANUT
ensanut <- ensanut %>%
  mutate(id = paste0(VIV_SEL,"_",NUMREN))

ensanut <- ensanut %>%
  mutate(Diabetes = ifelse(P3_1 == 1, 1, 0))

diseño <- svydesign(id = ~id, strata = ~EST_DIS, weights = ~F_20MAS,
                    PSU = ~UPM, data = ensanut, nest = TRUE)

svymean(~Diabetes, diseño)
svymean(~Diabetes, diseño) %>% confint()
svyquantile(~Diabetes, diseño, 0.75) 

ensanut <- ensanut %>%
  mutate(Infarto = ifelse(P5_1 == 1, 1, 0))

diseño <- svydesign(id = ~id, strata = ~EST_DIS, weights = ~F_20MAS,
                    PSU = ~UPM, data = ensanut, nest = TRUE)

svyhist(~P5_4, diseño, main = "Edad de diagnóstico", 
        xlab = "Edad cuando fue el primer infarto", breaks = 50, col = 'red', border = 'white')
